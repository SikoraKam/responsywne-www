const contacts = []
let id = -1

const deleteButton = () => {
    const btn = document.createElement("button")
    btn.setAttribute("id", `trashBtn${id}`)
    btn.setAttribute("class", `trashBtn`)
    btn.dataset.id=`${id}`

    btn.innerHTML = '<i style="pointer-events: none" class="fa-solid fa-trash"></i>'
    return btn
}

const row = () => {
    const row = document.createElement("div")
    row.setAttribute("id", `row${id}`)
    row.setAttribute("class", "row")
    row.innerHTML = '<div class="info">' +
        '<span style="font-size: 20px; font-weight: bold" id=`name${id}`>'
        + contacts[id]?.name + '</span>' +
        '<span  id=`phone${id}`>' + contacts[id]?.phone + '</span>' +
        '</div>'
    row.appendChild(deleteButton())
    return row
}
const displayContacts = () => {
    id++
    document.getElementById('displayContacts').appendChild(row())
}

const isNameValid = (nameAndLastName) => {
    const [name, lastName] = nameAndLastName.split(' ')

    if(name[0] !== name[0].toUpperCase() || lastName[0] !== lastName[0].toUpperCase())
        return false

    return /^[a-zA-Z-\s]+$/.test(nameAndLastName);
}

const convertAndCheckPhone = (phone) => {
    const removedWhitespaces = phone.replace(/\s/g, "");

    if(removedWhitespaces.length !== 9 && removedWhitespaces.length !== 12 && removedWhitespaces.length !== 13){
        return ''
    }
    else if (removedWhitespaces.length === 13 && removedWhitespaces[0] !== '+') {
        return ''
    }
    else if (!/^[0-9+]+$/.test(removedWhitespaces)){
        return ''
    }



    let onlyNumbers = removedWhitespaces.slice()
    let phoneWithSpaces = ''
    if(removedWhitespaces.length === 13){
        onlyNumbers = removedWhitespaces.substring(1)
        phoneWithSpaces = '+'
    }

    onlyNumbers.split('').forEach((number, index) => {
        if ((index + 1) % 3 === 0){
            phoneWithSpaces += (`${number} `)}
        else phoneWithSpaces += number
    })

    return phoneWithSpaces
}

const addNewContact = () => {
    const name = document.getElementById('inputName').value
    const phone = document.getElementById('inputPhone').value
    document.getElementById('errorName').innerText = ''
    document.getElementById('errorPhone').innerText = ''

    const nameValid = isNameValid(name)
    const convertedPhone = convertAndCheckPhone(phone)

    const contact = {
        name,
        phone: convertedPhone
    }

    if(nameValid && convertedPhone.length){
        contacts.push(contact)
        displayContacts();

        document.getElementById(`trashBtn${id}`).addEventListener("click", (e) => {
            deleteContact(e.target.dataset.id)
        })
    }

    if (!nameValid){
        document.getElementById('errorName').innerText = "Wpisz poprawne imię i nazwisko"
    }
    if(!convertedPhone.length){
        document.getElementById('errorPhone').innerText = "Wpisz poprawny telefon"
    }


    document.getElementById('inputName').value = ''
    document.getElementById('inputPhone').value = ''

}

const deleteContact = (idToDelete) => {
    contacts.splice(id,1)
    const rowToDelete = document.getElementById(   `row${idToDelete}`)
    document.getElementById('displayContacts').removeChild(rowToDelete)
    id--
}

const submitButton = document.getElementById('inputSubmit')

submitButton.addEventListener("click", (e) => {
    e.preventDefault()
    addNewContact()
})







const passwordInput= document.getElementById("password")
const confirmPasswordInput= document.getElementById("confirm-password")
const passwordButtons = document.querySelectorAll('.password-button')

const ruleIconSet = (isValid, ruleId) => {
    const rule = document.getElementById(ruleId)
    rule.dataset.checked = `${isValid}`
    const ruleIcon = rule.querySelector('i')
    if(isValid){
        ruleIcon.classList.remove('fa-circle-xmark')
        ruleIcon.classList.add('fa-circle-check')
    }
    else {
        ruleIcon.classList.remove('fa-circle-check')
        ruleIcon.classList.add('fa-circle-xmark')
    }
}

const checkMinimalCharacters = (password) => {
    return password.length >= 8
}

const checkOneSpecialCharacter = (password) => {
    const format =  /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
    return format.test(password)
}

const checkCapitalLetter = (password) => {
    return password !== password.toLowerCase()
}

const checkDigit = (password) => {
    return /\d/.test(password);
}

const checkConfirmPassword = () => {
    const errorLabel = document.getElementById('not-matched-label')
    if(passwordInput.value !== confirmPasswordInput.value){
        errorLabel.style.setProperty('display', 'block')
    }
    else {
        errorLabel.style.setProperty('display', 'none')
    }
}

const setRules = () => {
    ruleIconSet(checkMinimalCharacters(passwordInput.value), 'minimal-chars')
    ruleIconSet(checkOneSpecialCharacter(passwordInput.value), 'special-char')
    ruleIconSet(checkCapitalLetter(passwordInput.value), 'capital-letter')
    ruleIconSet(checkDigit(passwordInput.value), 'digit')
}

const changePasswordVisibility = (e) => {
    e.preventDefault()
    const button = e.target;
    const input = button.parentNode.querySelector('input')
    const isPasswordHidden = button.dataset.hidden === 'true'
    const icon = button.querySelector('i')


    if(isPasswordHidden){
        input.setAttribute('type', 'text')
        button.dataset.hidden = 'false'
        icon.classList.remove('fa-eye')
        icon.classList.add('fa-eye-slash')
    }
    else {
        input.setAttribute('type', 'password')
        button.dataset.hidden = 'true'
        icon.classList.remove('fa-eye-slash')
        icon.classList.add('fa-eye')
    }
}


passwordInput.addEventListener('input', () => {
    setRules()
    checkConfirmPassword()
})

confirmPasswordInput.addEventListener('input', () => {
    checkConfirmPassword()
})

passwordButtons.forEach((element) => {
    element.addEventListener('click', changePasswordVisibility)
})

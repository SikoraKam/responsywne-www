const ball = document.getElementById('ball')
const container = document.getElementById('container')
const info = document.getElementById('info')

const handleClick = (e) => {

    e.stopPropagation()

    info.style.setProperty('display', 'none')

    const ballBB = ball.getBoundingClientRect()
    const containerBB = container.getBoundingClientRect()

    const x = Math.max(0, Math.min(    e.clientX - containerBB.left - ballBB.width / 2,
        containerBB.width - ballBB.width
    ))

    const y = Math.max(0, Math.min(    e.clientY - containerBB.top - ballBB.height / 2,
        containerBB.height - ballBB.height
    ))

    ball.style.setProperty('--x', `${x}px`)
    ball.style.setProperty('--y', `${y}px`)

}

container.addEventListener('mousedown', handleClick);

window.addEventListener('mousedown', () => {
    info.style.setProperty('display', 'block')
})

//AAAAAAA
console.log("część A -----------")
function getRandomWord() {
  const length = Math.floor(Math.random() * (10 - 3) + 3);
  let result           = '';
  const characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  for ( let i = 0; i < length; i++ ) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

const tab = Array.from(Array(5)).map(() => getRandomWord())
// tablica i jej dlugosc
console.log(tab, tab.length)
//pierwszy element i dlugosc
console.log(tab[0], tab[0].length)
//ostatni element i dlugosc
console.log(tab[tab.length -1], tab[tab.length -1].length)

//BBBBBBBBBBBB
console.log("część B -----------")
console.log("foreach")
tab.forEach((elem, index) => {
  console.log(elem.toUpperCase())
  if(tab.length - 1 === index)
    console.log("PAW")
})
console.log("for")
for (let i = 0; i < tab.length; i++){
  console.log(tab[i].toUpperCase())
  if(tab.length - 1 === i)
    console.log("PAW")
}
console.log("for of")
for (const [index, elem] of tab.entries()){
  console.log(elem.toUpperCase())
  if(tab.length - 1 === index)
    console.log("PAW")
}
console.log("map")
tab.map((elem, index) => {
  console.log(elem.toUpperCase())
  if(tab.length - 1 === index)
    console.log("PAW")
})

// CCCCCCCCC
console.log("część C -----------")
const first = 'first'
const last = 'last'

tab.unshift(first)
tab.push(last)
console.log("tab length: ",tab.length)
console.table(tab)

// DDDDD
console.log("część D -----------")
if (tab.length >= 3){
  tab.splice(2,1)
  console.log(tab)
}

// EEEE
console.log("część E -----------")
const Users = [
  {name : "Grzegorz", age: 102},
  {name : "Ula", age: 18},
  {name : "Marcin", age: 33},
  {name : "Ola", age: 21},
  {name : "Gosia", age: 14},
  {name : "Henryk", age: 3},
  {name : "Piotr", age: 89},
]

for (const elem of Users){
  if(elem.age >= 18)
    console.log(elem.name)
}

Users.forEach(elem => {
  if(elem.age >= 18)
    console.log(elem.name)
})

const adults = Users.filter(elem => elem.age >= 18)
adults.forEach(elem => console.log(elem.name))



1

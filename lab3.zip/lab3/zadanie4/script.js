let count = 0
let isActive = false

counter = document.getElementById('counter')
eventHandler = document.getElementById('event')
countDisplay = document.getElementById('count-display')

function incrementAndDisplay () {
  count++
  countDisplay.innerHTML = count
}

eventHandler.addEventListener("click",() => {
  isActive = !isActive
  if(isActive) {
    eventHandler.innerText = "Remove event"
    counter.addEventListener("click", incrementAndDisplay)
  }else {
    count = 0
    countDisplay.innerHTML = count
    eventHandler.innerText = "Add event"
    counter.removeEventListener("click", incrementAndDisplay)
  }
})



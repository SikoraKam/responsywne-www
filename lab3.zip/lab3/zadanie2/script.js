const image = document.getElementById('image')
const button = document.getElementById('button')

let id = 0

const images = [
    { src: './img/morze.jpeg', borderColor: 'blue' },
    { src: './img/gory.jpeg', borderColor: 'red' },
    { src: './img/las.jpeg', borderColor: 'green' },
]

button.addEventListener('click', () => {
    id++
    id = id % images.length
    image.setAttribute('src', images[id].src)
    image.style.setProperty('--color', images[id].borderColor)
})


const one = document.querySelector('.one')
const two = document.querySelector('.two')
const three = document.querySelector('.three')

let sum = 0
const sumText = document.querySelector('.sum')

const propagationBtn = document.getElementById('propagation')
const resetBtn = document.getElementById('reset')
const directionBtn = document.getElementById('direction')
const logs = document.querySelector('.logs')

let propagation = false;
let direction = 'bubble'

const displayInfo = (amount, color) => {
    logs.insertAdjacentHTML('beforeend', `<li>nacisnąłeś ${color} o wartości ${amount}</li>`)
}

const listener = (event, amount) => {
    if(!propagation){
        event.stopPropagation();
    }
    sum += amount
    sumText.innerHTML = sum

    if (amount === 1) displayInfo(1, 'niebieski')
    else if (amount === 2) displayInfo(2, 'czerwony')
    else if (amount === 3) displayInfo(3, 'zolty')

    if(sum > 30){
        two.removeEventListener('click', addTwo, {capture: direction === 'capture'})
    }

    if(sum > 50){
        three.removeEventListener('click', addThree, {capture: direction === 'capture'})
    }
}

const addOne = (event) => {
    listener(event, 1)
}
const addTwo = (event) => {
    listener(event, 2)
}
const addThree = (event) => {
    listener(event, 3)
}

const addListeners = () => {
    one.addEventListener("click", addOne, {capture: direction === 'capture'})
    two.addEventListener("click", addTwo, {capture: direction === 'capture'})
    three.addEventListener("click", addThree, {capture: direction === 'capture'})
}

const removeListeners = () => {
    one.removeEventListener("click", addOne, {capture: direction === 'capture'})
    two.removeEventListener("click", addTwo, {capture: direction === 'capture'})
    three.removeEventListener("click", addThree, {capture: direction === 'capture'})
}

const resetFun = () => {
    sum = 0
    sumText.innerHTML = sum
    removeListeners()
    addListeners()
    direction = 'bubble'
    propagation = false
    logs.innerHTML = ''
}

const propagationChange = () => {
    propagation = !propagation
}

const directionChange = () => {
    removeListeners()
    direction = direction === 'bubble' ? 'capture' : "bubble"
    addListeners()
}


addListeners()
resetBtn.addEventListener('click', resetFun)
directionBtn.addEventListener('click', directionChange)
propagationBtn.addEventListener('click', propagationChange)

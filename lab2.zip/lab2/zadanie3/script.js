const button = document.querySelector('.dropbtn');
const menu = document.querySelector('.menu');
const menuButtons = document.querySelectorAll('.menu a');
const menuButtonsArray = Array.from(menuButtons);

button.addEventListener('click', () => {
    menu.classList.toggle('show');
    menuButtonsArray.forEach(link => {
        link.classList.toggle('link-animation')
    })
});


function closeNav () {
    menu.classList.toggle('show');
    menuButtonsArray.forEach(link => {
        link.classList.toggle('link-animation')
    })
}

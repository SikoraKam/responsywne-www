const getCities = async () => {
  try {
    const res = await fetch('http://localhost:3000/cities')
    if (!res.ok) throw new Error('Sth went wrong')
    return res.json()
  } catch (e) {
    console.error(e)
  }
}

async function main () {

  const cities = await getCities()

  // a). wyświetli na stronie tylko miasta z województwa małopolskiego
  const provinceFiltered = cities.filter(el => el.province.toLowerCase() === "małopolskie")
  const paragraph1 = document.getElementById('paragraph1')
  provinceFiltered.forEach(elem => {
    paragraph1.innerHTML += `${elem.name},&nbsp`
  })

  //b). wyświetli miasta które w swojej nazwie posiadają dwa znaki ‘a’
  const haveTwoCharsA = cities.filter(el => {
    const count = (el.name.match(/a/g)||[]).length;
    if (count === 2) return true
  })

  const paragraph2 = document.getElementById('paragraph2')
  haveTwoCharsA.forEach(elem => {
    paragraph2.innerHTML += `${elem.name},&nbsp`
  })

  //c). wyświetli piąte pod kątem gęstości zaludnienia miasto w Polsce.
  const sortedByDentensity = cities.sort((a, b ) => a.dentensity - b.dentensity)
  const spanDensity = `<span>${sortedByDentensity[4].name}</span>`
  document.getElementById('paragraph3').innerHTML += spanDensity

  //d). dla wszystkich miast powyżej 100000 dodać (na końcu) city do nazwy.
  const addedCity = cities.map(el => {
    if(el.people > 100000){
      return `${el.name}CITY`
    } else {
      return el.name
    }
  })
  const paragraph4 = document.getElementById('paragraph4')
  addedCity.forEach(elem => {
    paragraph4.innerHTML += `${elem},&nbsp`
  })

  // e) wyliczyć czy więcej jest miast powyżej 80000 mieszkańców czy poniżej wraz z informacją o
  // ich liczbie.
  const greater = cities.filter(el => el.people > 80000)
  const lower = cities.filter(el => el.people < 80000)
  const comparisonText = greater.length > lower.length ? `powyżej 80000 mieszkańców (${greater.length}) niż poniżej (${lower.length})` : `poniżej 80000 mieszkańców (${lower.length}) niż powyżej (${greater.length})`
  const spanCompare = `<span>${comparisonText}</span>`
  document.getElementById('paragraph5').innerHTML += spanCompare

  // f). jaka jest średnia powierzchnia miast z powiatów zaczynających się na literkę „P”

  const townshipStartWithP = cities.filter(el => el.township.toLowerCase().startsWith('p'))
  const areaSum = townshipStartWithP.reduce((sum, object) => {
      return sum + object.area
  }, 0);
  const averageArea = areaSum / townshipStartWithP.length ?? 0;
  const spanAvgArea = `<span>${averageArea}</span>`
  document.getElementById('paragraph6').innerHTML += spanAvgArea

  //g) odpowiedz na pytanie czy wszystkie miasta z województwa pomorskiego są większe od
  //5000 osób i ile jest takich miast.

  const provincePomorskie = cities.filter(el => el.province === 'pomorskie')
  const citiesGreaterThan5000people = provincePomorskie.filter(el => el.people > 5000)
  const text = provincePomorskie.length === citiesGreaterThan5000people.length
    ? `wszystkie miasta z woj pomorskiego mają więcej niż 5000 osób. Takich miast jest ${provincePomorskie.length}`
    : `nie wszystkie miasta z woj pomorskiego mają więcej niż 5000 osób. Tych co mają jest ${citiesGreaterThan5000people.length}`
  document.getElementById('paragraph7').innerText += text
}

main()






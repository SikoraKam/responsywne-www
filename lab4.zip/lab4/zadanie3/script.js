const clientId = 'Z8Yzo4A8wnpdXM2LH12J6mxpWOEOXEFsGRO5iupFAUI'
const searchInput = document.getElementById('searchInput')
const searchForm = document.getElementById('searchForm')
const gallery = document.getElementById('gallery')

const createRequestUrl = (inputValue) => {
  return `https://api.unsplash.com/search/photos?query='+${inputValue}+'&per_page=30&orientation=landscape&client_id=${clientId}`
}

const getPhotos = async (requestUrl) => {
  try {
    const res = await fetch(requestUrl)
    if (!res.ok) throw new Error('Sth went wrong')
    return res.json()
  } catch (e) {
    console.error(e)
  }
}

const createImg = (src) => {
  const img = document.createElement('img')
  img.setAttribute('src', src)
  img.setAttribute("alt", "image")
  return img
}

const onSearch = async (event) => {
  event.preventDefault()
  gallery.innerHTML = ""
  const inputValue = searchInput.value
  const url = createRequestUrl(inputValue)
  const photos = await getPhotos(url)
  console.log(photos)
  photos.results.forEach(photo => {
    gallery.appendChild(createImg(photo.urls.small))
  })
}




searchForm.addEventListener("submit", onSearch )

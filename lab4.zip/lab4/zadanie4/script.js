const mainList = document.getElementById('main-list')

const getFileContent = async (url) => {
    const res = await fetch(url)
    return res.json()
}

const createCheckboxCategory = (name) =>  {
    const input = document.createElement('input')
    input.setAttribute('type', 'checkbox')
    input.setAttribute('id', `categoryInput${name}`)

    const iconBtn = `<button data-category=${name} class="iconBtn" id=iconBtn${name}><i class="fa-solid fa-arrow-right"></i></button>`

    let row = `${iconBtn} <label for='categoryInput${name}'>${name}</label>`
    row += input.outerHTML
    return row
}

const createAndSetNestedList = (categoryName) => {
    const ul = document.createElement('ul')
    ul.setAttribute('id', `nestedList${categoryName}`)
    ul.dataset.isVisible = 'false'
    const mainListRow = document.getElementById(`listRow${categoryName}`)
    mainListRow.appendChild(ul)
}

const createAndSetCheckboxProduct = (productName, categoryName) =>  {
    const input = document.createElement('input')
    input.setAttribute('type', 'checkbox')
    input.setAttribute('id', `productInput${productName}`)
    input.dataset.value = productName;
    let row = `<label id="label${productName}" for='productInput${productName}'>${productName}</label>`
    row += input.outerHTML

    const nestedList = document.getElementById(`nestedList${categoryName}`)
    const li = document.createElement('li')
    li.setAttribute('id', `nestedListRow${productName}`)
    li.innerHTML += row

    nestedList.appendChild(li)
}


const addEventListenersToCheckbox = () => {
    const mainSection = document.getElementById('main-section')
    const checkBoxes = mainList.querySelectorAll('input')
    checkBoxes.forEach(checkbox => {
        checkbox.addEventListener('change', (event) => {

            if (checkbox.id.includes('categoryInput')){
                const nestedInputs = checkbox.parentNode.querySelector('ul').querySelectorAll('input')
                nestedInputs.forEach(checkbox => {
                    checkbox.checked = event.currentTarget.checked;
                    const triggerEvent = new Event("change", {"bubbles":true, "cancelable":false});
                    checkbox.dispatchEvent(triggerEvent);
                })

            }
            else {
                if (event.currentTarget.checked){
                    const li = document.createElement('li')
                    li.setAttribute('id', `mainSectionRow${checkbox.dataset.value}`)
                    li.innerHTML += checkbox.dataset.value
                    mainSection.appendChild(li)
                }
                else {
                    const li = document.getElementById(`mainSectionRow${checkbox.dataset.value}`)
                    li.outerHTML = '';
                }
            }


        })
    })
}

const addEventListenerToButtons = () => {
    const buttons = document.querySelectorAll('.iconBtn')
    buttons.forEach(button => {
        button.addEventListener('click', (event) => {
            const list = document.getElementById(`nestedList${button.dataset.category}`)
            list.dataset.isVisible = list.dataset.isVisible === 'false' ? 'true' : 'false'
            const icon = button.querySelector('i')
            if (list.dataset.isVisible === 'true'){
                icon.classList.remove('fa-arrow-right')
                icon.classList.add('fa-arrow-down')
            }
            else {
                icon.classList.remove('fa-arrow-down')
                icon.classList.add('fa-arrow-right')
            }


        })
    })
}

async function main(){
    const products1 = await getFileContent('http://localhost:3000/products')
    const products2 = await getFileContent('http://localhost:3001/products')

    console.log(products1)
    const joinedProducts = [...products1, ...products2]

    const categories = joinedProducts.map(categoryObject => Object.keys(categoryObject)[0])
    const categoriesWithoutDuplicates = [...new Set(categories)];

    categoriesWithoutDuplicates.forEach(category => {
        const checkboxRow = createCheckboxCategory(category)
        const li = document.createElement('li')
        li.setAttribute('id', `listRow${category}`)

        li.innerHTML += checkboxRow
        mainList.appendChild(li)

    })

    joinedProducts.forEach(element => {
        for (const [categoryName, productsAssignedToCategory] of Object.entries(element)) {
            if (!productsAssignedToCategory.length) continue
            createAndSetNestedList(categoryName)

            productsAssignedToCategory.forEach(product => {
                const nestedList = document.getElementById(`nestedList${categoryName}`)
                const liItems = nestedList.querySelectorAll('li')

                if (![...liItems].some(row => row.id === `nestedListRow${product.name}`)){
                    createAndSetCheckboxProduct(product.name, categoryName)

                }
            })
        }
    })

    addEventListenersToCheckbox()
    addEventListenerToButtons()



}

main()


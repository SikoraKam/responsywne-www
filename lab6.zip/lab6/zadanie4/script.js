const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const image = new Image();
image.src = "dog.jpeg";

const w = image.width / 2;
const h = image.height / 2;

const rectW = 200;
const rectH = 150;

image.onload = function () {
  ctx.drawImage(image, 50, 20, w, h);

  ctx.beginPath();
  ctx.rect(500, 20, rectW, rectH);
  ctx.closePath();
  ctx.stroke();

  ctx.scale(1.4, 0.7);
  ctx.drawImage(image, 0, 400, w, h);

  ctx.beginPath();
  ctx.rect(300, 400, rectW, rectH);
  ctx.closePath();
  ctx.stroke();

  ctx.scale(1, 1);
  ctx.rotate((Math.PI / 180) * 15);
  ctx.drawImage(image, 260, 700, w, h);

  ctx.beginPath();
  ctx.rect(550, 750, rectW, rectH);
  ctx.closePath();
  ctx.stroke();

  ctx.resetTransform();
  ctx.transform(1.2, 0.1, 0.1, 1.1, 30, 30);
  ctx.save();

  ctx.drawImage(image, -20, 800, w, h);

  ctx.beginPath();
  ctx.rect(300, 800, rectW, rectH);
  ctx.closePath();
  ctx.stroke();
};

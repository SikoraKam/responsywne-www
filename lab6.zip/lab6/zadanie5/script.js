const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
const colorInput = document.getElementById("color-input");
const colorBtn = document.getElementById("color");
const cutBtn = document.getElementById("cut");
const maskBtn = document.getElementById("mask");

let color = colorInput.value;
const image = new Image();

image.onload = function () {
  ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
};

image.src = "dog.jpeg";

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : null;
}

const updateColor = () => {
  const rgbColor = hexToRgb(color);

  let myImgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  let data = myImgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const avgR = (r + rgbColor.r) / 2;
    const avgG = (g + rgbColor.g) / 2;
    const avgB = (b + rgbColor.b) / 2;
    data[i] = avgR;
    data[i + 1] = avgG;
    data[i + 2] = avgB;
  }
  myImgData.data = data;
  ctx.putImageData(myImgData, 0, 0);
};

const cut = () => {
  const newImage = new Image();
  const src = canvas.toDataURL("image/jpeg", 1.0);

  newImage.onload = () => {
    ctx.drawImage(
      newImage,
      120,
      120,
      300,
      300,
      0,
      0,
      canvas.width,
      canvas.height
    );
  };
  newImage.src = src;
};

const putMask = () => {
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(canvas.width / 2, 20);
  ctx.lineTo(canvas.width - 20, canvas.height - 20);
  ctx.lineTo(20, canvas.height - 20);
  ctx.clip();

  const rgbColor = hexToRgb(color);
  ctx.fillStyle = `rgba(${rgbColor.r}, ${rgbColor.g}, ${rgbColor.b}, 0.5)`;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.restore();
};

colorInput.addEventListener("change", () => {
  color = colorInput.value;
});

colorBtn.addEventListener("click", () => {
  updateColor();
});

maskBtn.addEventListener("click", () => {
  putMask();
});

cutBtn.addEventListener("click", () => {
  cut();
});

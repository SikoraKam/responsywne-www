const inputs_list = document.querySelectorAll("input");
const inputs = [...inputs_list];
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
const calculateBtn = document.getElementById("calculate");

const getValuesAndColors = () => {
  return inputs.map((input) => {
    return { value: Number(input.value), color: input.style.backgroundColor };
  });
};

const calculateArcs = () => {
  const valuesAndColors = getValuesAndColors();

  let totalValues = valuesAndColors.reduce((sum, el) => sum + el.value, 0);

  let angle = 0;

  valuesAndColors.forEach((element) => {
    let portionAngle = (element.value / totalValues) * 2 * Math.PI;
    ctx.beginPath();
    ctx.arc(100, 100, 100, angle, angle + portionAngle);
    angle += portionAngle;
    ctx.lineTo(100, 100);
    ctx.fillStyle = element.color;
    ctx.fill();
  });
};

calculateBtn.addEventListener("click", () => {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  calculateArcs();
});

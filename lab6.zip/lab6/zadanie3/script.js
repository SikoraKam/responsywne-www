const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const image = new Image();

image.onload = function () {
  ctx.drawImage(image, 0, 0, image.width, image.height);
  ctx.drawImage(image, 120, 120, 100, 100, 0, 0, 100, 150);
  ctx.beginPath();
  ctx.strokeStyle = "#f00";
  ctx.lineWidth = 2;
  ctx.strokeRect(0, 0, 100, 150);
};
image.src = "dog.jpeg";

const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const drawBtn = document.getElementById("draw");
const cleanBtn = document.getElementById("clean");

const image = new Image();

image.onload = function () {
  drawBtn.addEventListener("click", () => {
    ctx.drawImage(image, 0, 0, image.width, image.height);
  });

  cleanBtn.addEventListener("click", () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  });
};
image.src = "dog.jpeg";

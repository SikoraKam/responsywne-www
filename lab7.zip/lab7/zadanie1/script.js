let boxes = document.querySelectorAll(".container .drag-box");
let dragElementFrom;

function dragStart(e) {
  dragElementFrom = e.target;

  e.dataTransfer.effectAllowed = "move";
  e.dataTransfer.setData("text/html", e.target.innerHTML);
}

function dragEnd(e) {
  boxes.forEach(function (item) {
    item.classList.remove("over");
  });
}

function handleDragOver(e) {
  e.preventDefault();
  return false;
}

function handleDragEnter(e) {
  e.target.classList.add("over");
}

function handleDragLeave(e) {
  e.target.classList.remove("over");
}

function handleDrop(e) {
  e.stopPropagation();
  if (dragElementFrom !== e.target) {
    dragElementFrom.innerHTML = e.target.innerHTML;
    e.target.innerHTML = e.dataTransfer.getData("text/html");
  }

  dragEnd(e);
  return false;
}

boxes.forEach((item) => {
  item.addEventListener("dragstart", dragStart);
  item.addEventListener("dragover", handleDragOver);
  item.addEventListener("dragenter", handleDragEnter);
  item.addEventListener("dragleave", handleDragLeave);
  item.addEventListener("dragend", dragEnd);
  item.addEventListener("drop", handleDrop);
});

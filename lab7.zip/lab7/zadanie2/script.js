const boxes = document.querySelectorAll(".container .drag-box");

function dragStart(e) {
  e.dataTransfer.effectAllowed = "move";
  e.dataTransfer.setData("text", e.target.getAttribute("id"));
}

function dragEnd(e) {}

function handleDragOver(e) {
  e.preventDefault();
  return false;
}

function handleDragEnter(e) {}

function handleDragLeave(e) {}

function handleDrop(e) {
  e.stopPropagation();
  const container = e.currentTarget;
  const dragElementId = e.dataTransfer.getData("text");
  const dragElement = document.getElementById(dragElementId);

  dragElement.remove();
  container.appendChild(dragElement);

  return false;
}

boxes.forEach((item) => {
  item.addEventListener("dragstart", dragStart);
  item.addEventListener("dragenter", handleDragEnter);
  item.addEventListener("dragleave", handleDragLeave);
  item.addEventListener("dragend", dragEnd);
});

const containers = document.querySelectorAll(".container");

containers.forEach((container) => {
  container.addEventListener("dragover", handleDragOver);
  container.addEventListener("drop", handleDrop);
});

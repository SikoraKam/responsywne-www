const boxes = document.querySelectorAll(".container .drag-box");
const addBtn = document.getElementById("addBtn");
const addInput = document.getElementById("todo-input");

const handleAddNewElement = (e) => {
  e.preventDefault();

  const todoList = document.getElementById("list-todo");
  const li = document.createElement("li");
  li.innerHTML = addInput.value;
  li.setAttribute("id", addInput.value);
  li.setAttribute("draggable", "true");
  li.classList.add("drag-box");

  li.addEventListener("dragstart", dragStart);
  li.addEventListener("dragenter", handleDragEnter);
  li.addEventListener("dragleave", handleDragLeave);
  li.addEventListener("dragend", dragEnd);
  todoList.appendChild(li);
  addInput.value = "";
};

function dragStart(e) {
  console.log(e.target);
  e.dataTransfer.effectAllowed = "move";
  e.dataTransfer.setData("text", e.target.getAttribute("id"));
}

function dragEnd(e) {}

function handleDragOver(e) {
  e.preventDefault();
  return false;
}

function handleDragEnter(e) {}

function handleDragLeave(e) {}

function handleDrop(e) {
  e.stopPropagation();
  const container = e.currentTarget;
  const dragElementId = e.dataTransfer.getData("text");
  const dragElement = document.getElementById(dragElementId);

  dragElement.remove();
  container.appendChild(dragElement);

  return false;
}

addBtn.addEventListener("click", handleAddNewElement);

boxes.forEach((item) => {
  item.addEventListener("dragstart", dragStart);
  item.addEventListener("dragenter", handleDragEnter);
  item.addEventListener("dragleave", handleDragLeave);
  item.addEventListener("dragend", dragEnd);
});

const containerLists = document.querySelectorAll(".container ul");

containerLists.forEach((containerList) => {
  containerList.addEventListener("dragover", handleDragOver);
  containerList.addEventListener("drop", handleDrop);
});

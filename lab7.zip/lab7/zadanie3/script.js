const container = document.querySelector(".container");
const info = document.querySelector(".info");

const createInfo = (file) => {
  const infoContent = `
  <span>name: ${file.name}</span>
  <span>size: ${file.size}</span>
  <span>type: ${file.type}</span>
  <span>last modified date: ${file?.lastModifiedDate}</span>
  `;

  info.innerHTML += infoContent;
};

function handleDragOver(e) {
  e.preventDefault();
  return false;
}

function handleDrop(e) {
  e.stopPropagation();
  e.preventDefault();
  const container = e.currentTarget;
  container.innerHTML = "";
  info.innerHTML = "";

  const file = e.dataTransfer.files[0];
  const imageType = /image.*/;
  if (!file.type.match(imageType)) {
    return false;
  }

  const img = document.createElement("img");
  img.file = file;
  const reader = new FileReader();
  reader.readAsDataURL(file);

  console.log(file);

  reader.onloadend = () => {
    img.src = reader.result;
    container.appendChild(img);
  };

  createInfo(file);

  return false;
}

container.addEventListener("dragover", handleDragOver);
container.addEventListener("drop", handleDrop);
